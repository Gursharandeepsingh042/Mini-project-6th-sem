from flask import Flask, request, jsonify, g
import sqlite3
import os

app = Flask(__name__)
DATABASE = 'numberplates.db'

# Connect to SQLite DB
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
    return db

# Close DB on app teardown
@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db:
        db.close()

# Initialize DB with number plates table
def init_db():
    with app.app_context():
        db = get_db()
        cursor = db.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS owners (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                plate_number TEXT UNIQUE NOT NULL,
                owner_name TEXT NOT NULL,
                contact_number TEXT NOT NULL
            )
        ''')
        db.commit()

# Add sample data to DB (run once or as needed)
def seed_db():
    with app.app_context():
        db = get_db()
        cursor = db.cursor()
        sample_data = [
            ('GJ19EQ0001', 'GURSHARAN DEEP SINGH', '9622599557'),
            ('MH12CD5678', 'Simran Kaur', '+918765432109'),
            ('PB10EF9012', 'Harpreet Dhillon', '+919812345678'),
        ]
        for plate, name, contact in sample_data:
            try:
                cursor.execute('INSERT INTO owners (plate_number, owner_name, contact_number) VALUES (?, ?, ?)',
                               (plate, name, contact))
            except sqlite3.IntegrityError:
                # Already exists
                pass
        db.commit()

@app.route('/owner/<plate_number>', methods=['GET'])
def get_owner(plate_number):
    db = get_db()
    cursor = db.cursor()
    cursor.execute('SELECT owner_name, contact_number FROM owners WHERE plate_number = ?', (plate_number,))
    row = cursor.fetchone()
    if row:
        owner_name, contact_number = row
        return jsonify({
            'plate_number': plate_number,
            'owner_name': owner_name,
            'contact_number': contact_number
        })
    else:
        return jsonify({'error': 'Number plate not found'}), 404

@app.route('/owner', methods=['POST'])
def add_owner():
    data = request.json
    plate_number = data.get('plate_number')
    owner_name = data.get('owner_name')
    contact_number = data.get('contact_number')

    if not plate_number or not owner_name or not contact_number:
        return jsonify({'error': 'Missing required fields'}), 400

    db = get_db()
    cursor = db.cursor()
    try:
        cursor.execute('INSERT INTO owners (plate_number, owner_name, contact_number) VALUES (?, ?, ?)',
                       (plate_number, owner_name, contact_number))
        db.commit()
        return jsonify({'message': 'Owner added successfully'}), 201
    except sqlite3.IntegrityError:
        return jsonify({'error': 'Plate number already exists'}), 409

if __name__ == '__main__':
    if not os.path.exists(DATABASE):
        init_db()
        seed_db()
    app.run(host='0.0.0.0', port=5000)
