from kivy.uix.screenmanager import Screen
from kivymd.toast import toast
from kivy.clock import Clock
from kivy.app import App
from myutils.api import make_call, send_sms

class ContactOptionsScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.phone_number = ""
        self.sms_scheduled = None
        self.call_scheduled = None

    def set_phone_number(self, phone_number):
        phone_number = phone_number.strip()
        if not phone_number.startswith('+'):
            phone_number = '+91' + phone_number
        self.phone_number = phone_number
        self.ids.phone_label.text = f"Phone: {self.phone_number}"

    def call_owner(self):
        if not self.phone_number:
            toast("No phone number available")
            return

        if self.call_scheduled:
            Clock.unschedule(self.call_scheduled)

        try:
            self.ids.notification_label.text = "Calling owner..."
            self.ids.notification_popup.open()
            make_call(self.phone_number)
            self.call_scheduled = Clock.schedule_once(
                lambda dt: self.show_call_confirmation(), 
                3
            )
        except Exception as e:
            self.ids.notification_label.text = f"Call failed: {str(e)}"
            self.ids.notification_popup.open()

    def send_sms_to_owner(self):
        if not self.phone_number:
            toast("No phone number available")
            return

        message = self.ids.message_input.text.strip()
        if not message:
            toast("Please enter a message")
            return

        if self.sms_scheduled:
            Clock.unschedule(self.sms_scheduled)

        try:
            self.ids.notification_label.text = "Sending SMS..."
            self.ids.notification_popup.open()
            send_sms(self.phone_number, message)
            self.sms_scheduled = Clock.schedule_once(
                lambda dt: self.show_sms_confirmation(), 
                3
            )
        except Exception as e:
            self.ids.notification_label.text = f"SMS failed: {str(e)}"
            self.ids.notification_popup.open()

    def show_call_confirmation(self):
        self.ids.notification_label.text = "Owner contacted successfully!"
        self.call_scheduled = None

    def show_sms_confirmation(self):
        self.ids.notification_label.text = "SMS sent successfully!"
        self.ids.message_input.text = ""
        self.sms_scheduled = None

    def dismiss_notification(self):
        self.ids.notification_popup.dismiss()
        if self.call_scheduled:
            Clock.unschedule(self.call_scheduled)
        if self.sms_scheduled:
            Clock.unschedule(self.sms_scheduled)
        App.get_running_app().stop()