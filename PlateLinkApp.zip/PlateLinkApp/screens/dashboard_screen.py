from kivy.uix.screenmanager import Screen
from kivymd.uix.button import MDFloatingActionButton, MDFlatButton, MDIconButton
from kivymd.uix.dialog import MDDialog
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.textfield import MDTextField
from kivy.metrics import dp

class DashboardScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.detected_plate = ""
        self.alert_dialog = None
        self.message_field = None
        self.fab = None
        self.logout_button = None

    def on_enter(self, *args):
        # Add camera FAB button if not already added
        if not self.fab and hasattr(self.ids, 'anchor_layout'):
            self.fab = MDFloatingActionButton(
                icon="camera",
                elevation=8,
                md_bg_color=[0, 0.5, 0.8, 1],
                size_hint=(None, None),
                size=(dp(56), dp(56))
            )
            self.fab.bind(on_release=self.open_scan_screen)
            self.ids.anchor_layout.add_widget(self.fab)

            # Add Logout button
            self.logout_button = MDIconButton(
                icon="logout",
                pos_hint={"center_x": 0.9, "center_y": 0.95},
                theme_text_color="Custom",
                text_color=[1, 0, 0, 1]
            )
            self.logout_button.bind(on_release=self.logout_user)
            self.ids.anchor_layout.add_widget(self.logout_button)

    def open_scan_screen(self, *args):
        # Switch to scan screen
        self.manager.current = "scan_screen"

    def show_alert_options(self, plate_number):
        # Show alert dialog with detected plate and message field
        self.detected_plate = plate_number
        if not self.alert_dialog:
            self.message_field = MDTextField(
                hint_text="Enter your message...",
                multiline=True,
                max_height=dp(100),
                mode="rectangle"
            )
            content = MDBoxLayout(
                orientation="vertical",
                spacing=dp(12),
                adaptive_height=True
            )
            content.add_widget(self.message_field)

            self.alert_dialog = MDDialog(
                title=f"Plate Detected: {self.detected_plate}",
                type="custom",
                content_cls=content,
                buttons=[
                    MDFlatButton(text="CALL OWNER", on_release=self.make_call),
                    MDFlatButton(text="SEND SMS", on_release=self.send_sms),
                    MDFlatButton(text="CANCEL", on_release=lambda x: self.alert_dialog.dismiss()),
                ],
            )
        else:
            self.alert_dialog.title = f"Plate Detected: {self.detected_plate}"
            self.message_field.text = ""

        self.alert_dialog.open()

    def make_call(self, *args):
        print(f"Calling owner of vehicle: {self.detected_plate}")
        self.alert_dialog.dismiss()

    def send_sms(self, *args):
        message = self.message_field.text.strip()
        if message:
            print(f"Sending SMS to {self.detected_plate}: {message}")
        else:
            print("No message entered")
        self.alert_dialog.dismiss()

    def logout_user(self, *args):
        print("User logged out. Returning to login screen.")
        self.manager.current = "login_screen"

    def on_leave(self, *args):
        # Dismiss alert dialog if open
        if self.alert_dialog and self.alert_dialog.open:
            self.alert_dialog.dismiss()
        super().on_leave(*args)
