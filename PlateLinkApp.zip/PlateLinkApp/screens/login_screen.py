from kivymd.uix.screen import MDScreen
from kivy.properties import StringProperty, BooleanProperty
from kivymd.toast import toast
from kivy.clock import Clock
from myutils.api import send_otp, verify_otp

class LoginScreen(MDScreen):
    # Login properties
    user_email = StringProperty("")
    user_password = StringProperty("")
    login_loading = BooleanProperty(False)

    # Signup properties
    signup_name = StringProperty("")
    signup_lastname = StringProperty("")
    signup_email = StringProperty("")
    signup_password = StringProperty("")
    signup_phone = StringProperty("")
    signup_loading = BooleanProperty(False)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        Clock.schedule_once(self.setup_fields)

    def setup_fields(self, dt):
        # Placeholder for any initialization or reset
        pass

    def validate_phone(self, phone):
        """Validate Indian phone number (10 digits, numeric only)"""
        valid = phone.isdigit() and len(phone) == 10
        if not valid:
            toast("Enter a valid 10-digit Indian number")
        return valid

    def login_user(self):
        email = self.user_email.strip()
        password = self.user_password.strip()

        if not email or not password:
            toast("Please enter both email and password")
            return

        self.login_loading = True
        Clock.schedule_once(lambda dt: self._perform_login(email, password), 0.1)

    def _perform_login(self, email, password):
        try:
            # Replace with your real auth call
            if email == "gursharansinghleh@gmail.com" and password == "12345678" or email=="raghav042@gmail.com" and password=="12345678" or email=="2022a1r024@gmail.com" and password== "12345678" :
                toast("Login successful")
                self.manager.current ="dashboard"  # Move to dashboard screen
            else:
                toast("Invalid credentials")
        except Exception as e:
            toast(f"Login error: {str(e)}")
        finally:
            self.login_loading = False

    def send_signup_otp(self):
        phone = self.signup_phone.strip()

        if not self.validate_phone(phone):
            return

        self.signup_loading = True
        Clock.schedule_once(lambda dt: self._send_otp_async(phone), 0.1)

    def _send_otp_async(self, phone):
        try:
            result = send_otp(phone)
            if result == 'pending':
                toast(f"OTP sent to {phone}")
                self.navigate_to_otp_screen(phone)
            else:
                toast("OTP sending failed")
        except Exception as e:
            toast(f"Error sending OTP: {str(e)}")
        finally:
            self.signup_loading = False

    def navigate_to_otp_screen(self, phone):
        try:
            if 'otp_verification' not in self.manager.screen_names:
                from screens.otp_verification_screen import OTPVerificationScreen
                self.manager.add_widget(OTPVerificationScreen(name='otp_verification'))

            otp_screen = self.manager.get_screen('otp_verification')
            otp_screen.phone_number = phone  # Make sure this property exists in OTPVerificationScreen
            self.manager.current = 'otp_verification'
        except Exception as e:
            toast(f"Navigation error: {str(e)}")

    def signup_user(self):
        name = self.signup_name.strip()
        lastname = self.signup_lastname.strip()
        email = self.signup_email.strip()
        password = self.signup_password.strip()

        if not all([name, lastname, email, password]):
            toast("Fill all required fields")
            return

        if len(password) < 6:
            toast("Password must be at least 6 characters")
            return

        # Replace with actual registration API call
        toast(f"Welcome {name}! Registration complete")
        self.clear_signup_fields()
        self.manager.current = "dashboard"  # Move to dashboard screen

    def clear_signup_fields(self):
        self.signup_name = ""
        self.signup_lastname = ""
        self.signup_email = ""
        self.signup_password = ""
        self.signup_phone = ""

    def switch_to_signup(self):
        try:
            self.ids.screen_manager.current = "signup"
        except Exception as e:
            toast(f"Switch to signup error: {str(e)}")

    def switch_to_login(self):
        try:
            self.ids.screen_manager.current = "login"
        except Exception as e:
            toast(f"Switch to login error: {str(e)}")
