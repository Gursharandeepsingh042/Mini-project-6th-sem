from kivymd.uix.screen import MDScreen
from kivy.properties import StringProperty, BooleanProperty
from kivymd.toast import toast
from kivy.clock import Clock
import threading
from myutils.api import verify_otp

class OTPVerificationScreen(MDScreen):
    phone_number = StringProperty("")
    otp_code = StringProperty("")
    loading = BooleanProperty(False)

    def verify_otp(self):
        """Validate and verify OTP without freezing UI"""
        if len(self.otp_code) != 6 or not self.otp_code.isdigit():
            toast("Enter 6-digit OTP")
            return

        self.loading = True
        # Start a background thread for verification
        threading.Thread(target=self._verify_otp_thread, daemon=True).start()

    def _verify_otp_thread(self):
        try:
            result = verify_otp(self.phone_number, self.otp_code)
            # Update UI on main thread
            Clock.schedule_once(lambda dt: self._handle_verification_result(result))
        except Exception as e:
            Clock.schedule_once(lambda dt: toast(f"Verification error: {str(e)}"))
            Clock.schedule_once(lambda dt: self._set_loading(False))

    def _handle_verification_result(self, result):
        if result == 'approved':
            toast("Verification successful!")
            self.manager.current ='dashboard'
        else:
            toast("Invalid OTP code")
        self.loading = False

    def _set_loading(self, value):
        self.loading = value

    def resend_otp(self):
        """Handle OTP resend"""
        toast("New OTP sent")
        # TODO: implement actual resend logic
