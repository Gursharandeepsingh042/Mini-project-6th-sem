from kivy.uix.screenmanager import Screen
from kivy.uix.widget import Widget
from kivy.clock import Clock
from kivy.graphics.texture import Texture
from kivy.graphics import Color, Line
from kivy.properties import NumericProperty, StringProperty, ListProperty, BooleanProperty, ObjectProperty
from kivy.animation import Animation
from kivy.metrics import dp
from kivy.utils import get_color_from_hex
import cv2
import threading
import requests
import easyocr
import numpy as np
import re


class ScannerAnimation(Widget):
    line_y = NumericProperty(0)
    box_size = NumericProperty(0)
    box_pos = ListProperty([0, 0])
    is_active = BooleanProperty(False)
    line_color = ListProperty([0, 1, 0, 0.8])

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.anim = None
        self.bind(size=self.update_properties, pos=self.update_properties)

    def update_properties(self, *args):
        min_dim = min(self.width, self.height)
        self.box_size = min_dim * 0.7
        self.box_pos = [
            (self.width - self.box_size) / 2,
            (self.height - self.box_size) / 2
        ]
        self.update_canvas()

    def start_animation(self):
        if self.is_active:
            return
        self.is_active = True
        self.line_y = self.box_pos[1]

        anim_up = Animation(
            line_y=self.box_pos[1] + self.box_size - dp(40),
            duration=1.2,
            transition='linear'
        )
        anim_down = Animation(
            line_y=self.box_pos[1],
            duration=1.2,
            transition='linear'
        )
        self.anim = anim_up + anim_down
        self.anim.repeat = True
        self.anim.start(self)

    def stop_animation(self):
        if self.anim:
            self.anim.cancel(self)
        self.is_active = False
        self.canvas.clear()

    def update_canvas(self):
        if not self.is_active:
            return
        self.canvas.clear()
        with self.canvas:
            Color(1, 1, 1, 0.8)
            Line(rectangle=(*self.box_pos, self.box_size, self.box_size), width=2)
            Color(*self.line_color)
            Line(points=[self.box_pos[0], self.line_y,
                         self.box_pos[0] + self.box_size, self.line_y],
                 width=3)


class ScanScreen(Screen):
    detected_plate = StringProperty('')
    camera_error = StringProperty('')
    is_processing = BooleanProperty(False)
    fps = NumericProperty(30)
    scanning = BooleanProperty(False)
    _texture = ObjectProperty(None)
    _plate_text_color = ListProperty([1, 1, 1, 1])
    _status_text_color = ListProperty([1, 1, 1, 0.5])
    _current_frame = None  # Stores the current frame for display
    _capture_frame = None  # Stores the frame to be processed

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.capture = None
        self.frame_thread = None
        self.reader = easyocr.Reader(['en'], gpu=False)

    def on_enter(self):
        if not self.scanning:
            self.start_camera()

    def on_leave(self):
        self.stop_camera()

    def start_camera(self):
        if self.scanning:
            return
        try:
            self.capture = cv2.VideoCapture(0, cv2.CAP_DSHOW)
            self.capture.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            self.capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            self.capture.set(cv2.CAP_PROP_FPS, self.fps)
            self.capture.set(cv2.CAP_PROP_BUFFERSIZE, 1)

            self.scanning = True
            self.camera_error = ''
            self.detected_plate = ''
            Clock.schedule_once(lambda dt: setattr(self, '_plate_text_color', [1, 1, 1, 1]))
            Clock.schedule_once(lambda dt: setattr(self, '_status_text_color', [1, 1, 1, 0.5]))

            if hasattr(self, 'scanner'):
                self.scanner.stop_animation()
                Clock.schedule_once(lambda dt: setattr(self.scanner, 'line_color', [1, 1, 1, 0.8]))
                
            self.frame_thread = threading.Thread(target=self._frame_loop, daemon=True)
            self.frame_thread.start()

            Clock.schedule_interval(self._update_display, 1 / self.fps)

        except Exception as e:
            self.camera_error = f"Camera error: {str(e)}"
            self.stop_camera()

    def stop_camera(self):
        self.scanning = False
        if hasattr(self, 'scanner'):
            self.scanner.stop_animation()
        if self.capture:
            self.capture.release()
        Clock.unschedule(self._update_display)

    def capture_and_scan(self):
        """Captures the current frame and initiates scanning"""
        if not self.scanning or self._current_frame is None:
            return

        self._capture_frame = self._current_frame.copy()
        self.is_processing = True
        threading.Thread(target=self._process_captured_frame, daemon=True).start()

    def _process_captured_frame(self):
        """Processes the manually captured frame"""
        try:
            frame = self._adjust_frame(self._capture_frame)
            self._process_roi(frame)
        except Exception as e:
            print(f"Frame processing error: {e}")
            self.is_processing = False

    def _frame_loop(self):
        while self.scanning:
            ret, frame = self.capture.read()
            if not ret:
                Clock.schedule_once(lambda dt: setattr(self, 'camera_error', "Camera feed error"))
                break
            self._current_frame = frame

    def _update_display(self, dt):
        """Updates the display with the latest frame"""
        if not self.scanning or self._current_frame is None:
            return

        try:
            frame = self._adjust_frame(self._current_frame)
            self._update_texture(frame)
        except Exception as e:
            print(f"Display update error: {e}")

    def _adjust_frame(self, frame):
        frame = cv2.rotate(frame, cv2.ROTATE_180)
        frame = cv2.flip(frame, 1)
        return frame

    def _update_texture(self, frame):
        try:
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            if self._texture is None:
                self._texture = Texture.create(size=(frame.shape[1], frame.shape[0]), colorfmt='rgb')
            self._texture.blit_buffer(frame_rgb.tobytes(), colorfmt='rgb', bufferfmt='ubyte')
            self.canvas.ask_update()
        except Exception as e:
            print(f"Texture error: {e}")

    def _process_roi(self, frame):
        if not hasattr(self, 'scanner'):
            self.is_processing = False
            return

        box_size = int(self.scanner.box_size)
        box_x, box_y = self.scanner.box_pos
        frame_h, frame_w = frame.shape[:2]
        scale_x = frame_w / self.width
        scale_y = frame_h / self.height
        x1 = int(box_x * scale_x)
        y1 = int(box_y * scale_y)
        x2 = int((box_x + box_size) * scale_x)
        y2 = int((box_y + box_size) * scale_y)
        roi = frame[y1:y2, x1:x2]

        threading.Thread(target=self._detect_plate_and_ocr, args=(roi,), daemon=True).start()

    def _detect_plate_and_ocr(self, roi):
        try:
            gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
            filtered = cv2.bilateralFilter(gray, 13, 25, 25)
            thresh = cv2.adaptiveThreshold(filtered, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                          cv2.THRESH_BINARY, 11, 2)
            edged = cv2.Canny(thresh, 30, 200)

            contours, _ = cv2.findContours(edged.copy(), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
            contours = sorted(contours, key=lambda c: cv2.contourArea(c) + cv2.arcLength(c, True), reverse=True)[:10]

            plate_candidate = None
            for cnt in contours:
                peri = cv2.arcLength(cnt, True)
                approx = cv2.approxPolyDP(cnt, 0.02 * peri, True)
                if len(approx) == 4:
                    x, y, w, h = cv2.boundingRect(approx)
                    aspect_ratio = w / float(h)
                    if 2.5 <= aspect_ratio <= 5.5 and w > 50 and h > 10:
                        plate_candidate = roi[y:y + h, x:x + w]
                        break

            if plate_candidate is None:
                print("No plate candidate found")
                return

            plate_gray = cv2.cvtColor(plate_candidate, cv2.COLOR_BGR2GRAY)
            plate_gray = cv2.equalizeHist(plate_gray)
            _, plate_thresh = cv2.threshold(plate_gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            resized_plate = cv2.resize(plate_thresh, (plate_thresh.shape[1] * 3, plate_thresh.shape[0] * 3),
                                      interpolation=cv2.INTER_CUBIC)
            results = self.reader.readtext(resized_plate, detail=1)

            plate_text = ''
            max_confidence = 0
            for bbox, text, confidence in results:
                cleaned_text = ''.join(filter(str.isalnum, text)).upper()
                if 6 <= len(cleaned_text) <= 12:
                    if confidence > 0.6 and self._is_valid_plate(cleaned_text):
                        if confidence > max_confidence:
                            plate_text = cleaned_text
                            max_confidence = confidence

            if plate_text:
                print(f"OCR Detected Plate: {plate_text} (Confidence: {max_confidence:.2f})")
                self.detected_plate = plate_text
                Clock.schedule_once(lambda dt: setattr(self, '_plate_text_color', [0, 1, 0, 1]))
                Clock.schedule_once(lambda dt: setattr(self, '_status_text_color', [0, 1, 0, 0.7]))
                if hasattr(self, 'scanner'):
                    Clock.schedule_once(lambda dt: setattr(self.scanner, 'line_color', [0, 1, 0, 0.8]))
                self._handle_detection(plate_text)
            else:
                print("No valid plate text found")
                self.detected_plate = ''
                Clock.schedule_once(lambda dt: setattr(self, '_plate_text_color', [1, 1, 1, 1]))
                Clock.schedule_once(lambda dt: setattr(self, '_status_text_color', [1, 1, 1, 0.5]))
                if hasattr(self, 'scanner'):
                    Clock.schedule_once(lambda dt: setattr(self.scanner, 'line_color', [1, 1, 1, 0.8]))

        except Exception as e:
            print(f"OCR/Detection error: {e}")
            self.detected_plate = ''
            Clock.schedule_once(lambda dt: setattr(self, '_plate_text_color', [1, 0, 0, 1]))
            Clock.schedule_once(lambda dt: setattr(self, '_status_text_color', [1, 0, 0, 0.7]))
            if hasattr(self, 'scanner'):
                Clock.schedule_once(lambda dt: setattr(self.scanner, 'line_color', [1, 0, 0, 0.8]))

        finally:
            self.is_processing = False

    def _is_valid_plate(self, text):
        pattern = r'^[A-Z]{2}[0-9]{1,2}[A-Z0-9]{1,5}[0-9]{1,4}$'
        return re.match(pattern, text) is not None

    def _handle_detection(self, plate_text):
        self.detected_plate = plate_text
        threading.Thread(target=self._fetch_owner_info, args=(plate_text,), daemon=True).start()

    def _fetch_owner_info(self, plate_text):
        try:
            response = requests.get(f"http://127.0.0.1:5000/api/lookup/{plate_text}", timeout=3)
            if response.status_code == 200:
                owner_data = response.json()
                Clock.schedule_once(lambda dt: self._show_owner_info(plate_text, owner_data))
        except Exception as e:
            print(f"API error: {e}")

    def _show_owner_info(self, plate_text, owner_data):
        if hasattr(self, 'manager') and self.manager:
            contact_screen = self.manager.get_screen('contact_screen')
            if hasattr(contact_screen, 'set_owner_info'):
                contact_screen.set_owner_info(plate_text, owner_data)
            self.manager.current = 'contact_screen'