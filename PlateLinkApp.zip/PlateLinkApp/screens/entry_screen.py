from kivy.uix.screenmanager import Screen
from kivy.clock import Clock
from kivy.properties import BooleanProperty, NumericProperty

class EntryScreen(Screen):
    loading = BooleanProperty(True)
    transition_delay = NumericProperty(0.3)  # ADJUSTABLE: Delay after video ends
    fade_duration = NumericProperty(0.2)     # ADJUSTABLE: Transition duration
    
    def on_enter(self):
        self.loading = True
        self.ids.intro_video.state = 'play'
        
    def on_video_finish(self, instance):
        self.loading = False
        Clock.schedule_once(self.go_to_login, self.transition_delay)
    
    def go_to_login(self, dt):
        if self.manager:
            self.manager.transition.duration = self.fade_duration
            self.manager.current = 'login'