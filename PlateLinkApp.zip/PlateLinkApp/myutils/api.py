from twilio.rest import Client

# Twilio config — replace with your actual details
account_sid = 'ACef3daa3d78bd84dff67421e031fafb02'
auth_token = 'ebd3e594754660797cbb8cc016b5f8f1'
verify_sid = 'VA89f29f331e77c50467429d9cf15e9c78'
twilio_phone_number = '+14155238886'  # Replace with your Twilio number (must be voice and SMS enabled)

# Twilio client setup
client = Client(account_sid, auth_token)

# ----------------------------- OTP Functions -----------------------------

def send_otp(phone_number):
    """Send OTP to given phone number using Twilio Verify API."""
    if not phone_number.startswith('+'):
        phone_number = '+91' + phone_number  # Assuming Indian numbers
    verification = client.verify.services(verify_sid).verifications.create(
        to=phone_number,
        channel='sms'
    )
    return verification.status  # 'pending' if OTP sent


def verify_otp(phone_number, code):
    """Verify OTP code for given phone number using Twilio Verify API."""
    if not phone_number.startswith('+'):
        phone_number = '+91' + phone_number
    verification_check = client.verify.services(verify_sid).verification_checks.create(
        to=phone_number,
        code=code
    )
    return verification_check.status  # 'approved' if OTP correct

# ----------------------------- Call & SMS Functions -----------------------------

def make_call(phone_number):
    """Trigger a voice call to given number using Twilio Voice API."""
    if not phone_number.startswith('+'):
        phone_number = '+91' + phone_number
    call = client.calls.create(
        to=phone_number,
        from_=twilio_phone_number,
        twiml='<Response><Say>Alert. This is an emergency notification regarding your vehicle. Please check immediately.</Say></Response>'
    )
    return call.sid


def send_sms(phone_number, message):
    """Send SMS to given phone number using Twilio Messaging API."""
    if not phone_number.startswith('+'):
        phone_number = '+91' + phone_number
    sms = client.messages.create(
        body=message,
        from_=twilio_phone_number,
        to=phone_number
    )
    return sms.sid
