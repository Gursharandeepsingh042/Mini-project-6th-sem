# ocr.py
import cv2
import pytesseract
import re

def extract_number_plate_text(image):
    try:
        # Convert to grayscale for better OCR
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        # Apply bilateral filter to reduce noise while keeping edges sharp
        filtered = cv2.bilateralFilter(gray, 11, 17, 17)

        # Edge detection for clarity
        edged = cv2.Canny(filtered, 30, 200)

        # OCR
        text = pytesseract.image_to_string(filtered, config='--psm 7')

        # Clean the text — basic regex to grab probable plate numbers
        plate_number = re.sub(r'[^A-Z0-9]', '', text.upper())

        # Optional sanity check — typical Indian plates are 6-10 chars
        if 6 <= len(plate_number) <= 10:
            return plate_number
        else:
            return None

    except Exception as e:
        print(f"OCR extraction error: {e}")
        return None
