from kivymd.app import MDApp
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager, FadeTransition

# Import screens
from screens.login_screen import LoginScreen
from screens.otp_verification_screen import OTPVerificationScreen
from screens.dashboard_screen import DashboardScreen
from screens.scan_screen import ScanScreen
from screens.contact_options_screen import ContactOptionsScreen

class PlateLinkApp(MDApp):
    def build(self):
        # Set theme for the app
        self.theme_cls.primary_palette = "Blue"
        self.theme_cls.theme_style = "Light"

        # Load KV files
        Builder.load_file('kv/login_screen.kv')
        Builder.load_file('kv/otp_verification_screen.kv')
        Builder.load_file('kv/dashboard_screen.kv')
        Builder.load_file('kv/scan_screen.kv')
        Builder.load_file('kv/contact_options_screen.kv')

        # Initialize ScreenManager
        sm = ScreenManager(transition=FadeTransition())

        # Add screens
        sm.add_widget(LoginScreen(name='login'))
        sm.add_widget(OTPVerificationScreen(name='otp'))
        sm.add_widget(DashboardScreen(name='dashboard'))
        sm.add_widget(ScanScreen(name='scan_screen'))
        sm.add_widget(ContactOptionsScreen(name='contact'))

        # Set initial screen
        sm.current = 'dashboard'

        return sm

if __name__ == '__main__':
    PlateLinkApp().run()
